Fig 1 has been created in Solidworks
The "DoubleFiltering_Robust_WithParallel" has been used to create Figs: 2, 5, 6, 7, 8, 9, 10, 14 & 15
The "SingleFiltering_Robust_WithParallel" has been used to create Figs: 11 & 12
The "SingleFiltering_NonRobust_NoParallel" has been used to create Fig: 13
The MATLAB program "Heaviside_plots.m" has been used to create: Figs 3 & 4