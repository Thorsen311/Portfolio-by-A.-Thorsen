from fenics import *
from fenics_adjoint import *
from cantilever_bracket import CantileverBracket
from filter_and_project import FilterAndProject
import numpy as np
from mma import MMA_petsc

class topOpt(MMA_petsc):
    def __init__(self):
        # MPI rank
        self.rank=MPI.rank(MPI.comm_world)

        # Directory for output
        self.directory='topopt_elasticity_bracket/'

        # Some constants
        
        # Some constants       
        density = 7850     # Density, [kg/m^3] 
        L1 = 40e-3              # Length, [m]
        L2 = 40e-3
        R1 = 30e-3
        R2 = 30e-3
        R3 = 12.5e-3
        g = 9.81
        F = -1000          # Total force, [N]
        Wz = 20e-3           #Thickness
        W = L2+R1+2*R2
        
        self.E0 = 111e9      # Youngs modulus, [Pa]
        self.nu = 0.3387     # Poissons ration, [1]
        mesh_size=W/80     # Mesh size
        
        self.Volfrac=0.5
        self.VolMax= (L1*L2) + (((L1+R1)*R1) - 1/4*np.pi*R1**2) + (( (L1+R1)*2*R2 ) + (1/2*np.pi*R2**2) - (np.pi*R3**2)) 
        
        R=W/8/(2*np.sqrt(3))  # Filter Radius ~ W/8
        #R=2*mesh_size/(2*np.sqrt(3))  # Minimum filter Radius
        self.Emin=self.E0/1e6 # Minimum E
        self.pen=3            # SIMP penalization 
        
        self.mech=CantileverBracket(L1,L2,R1,R2,R3,Wz,self.E0,self.nu,F,density,mesh_size)#,cell_type=CellType.Type.hexahedron)
        
        self.FP=FilterAndProject(R,self.mech.mesh)
        self.rho=interpolate(Constant(0.5),self.FP.Vd)
        #self.rho=interpolate( Expression('abs(0.5*sin(x[0]+x[1])+0.35)', degree=1) ,self.FP.Vd)
        self.rho.rename('rho','rho')
        self.rho_petsc=as_backend_type(self.rho.vector()).vec()  # Pointer to rho's petsc data structure

        # Set up optimizer
        # Number of constraints
        self.ncon=1
        self.setUpOptimizer( self.rho_petsc )

    
    def setUpOptimizer(self,x0):
        """Initializes MMA"""
        MMA_petsc.__init__(self,x0,self.ncon)
        self.xmin[:]=0.0
        self.xmax[:]=1.0

        # MMA setup
        self.move=0.5
        self.xtol=0.01
        self.ftol=0.001
        self.lmax=5
        self.kmax=30
        self.kmin=30
        self.it=0
        self.mma_timing=False  

    def Forward(self,beta,eta):
        rho_tilde=self.FP.filter(self.rho)
        rho_bar,_=self.FP.Heavi_project(beta,eta,rho_tilde)
        #rho_tilde=self.rho # Use to "turn off" filtering
        #rho_bar=rho_tilde  # and projection
        E=self.Emin+pow(rho_bar,self.pen)*(self.E0-self.Emin) # SIMP E
        self.mech.E=E
        self.mech.mask=rho_bar
        u=self.mech.solve()
        return (u,rho_bar,rho_tilde)

    def plot_k(self,x,force_plot=False):
        """Abstract method from mma, which can be used for output during optimization""" 
        if force_plot or self.iter % self.nout == 0:
            if not force_plot:
                self.rho.vector().set_local(self.x.getArray()[:])
                self.rho.vector().apply('')

            (u,rho_bar,rho_tilde)=self.Forward(self.beta,self.eta)
            
            self.u_fid << u,self.iter
            self.rho_fid << self.rho,self.iter
            self.rhoFil_fid << rho_tilde,self.iter
            self.rhoPhys_fid << rho_bar,self.iter
        self.iter+=1

    def setUpFunctionals(self,beta,eta):
        from pyadjoint.tape import annotate_tape
        while not annotate_tape():
            continue_annotation() # Run continue until we actually start annotating...
        tape=get_working_tape()
        tape.clear_tape()
        # Run forward model to record on tape
        (u,rhoPhys,rhoFil)=self.Forward(beta,eta)
        eps=self.mech.epsilon(u)
        sig=self.mech.sigma(u,eps)
        # Using annotate=False to not record this step, such that J0 does not depend on rho
        if beta==1:
            self.J0=float(assemble(0.5*inner(sig,eps)*dx,annotate=False))
        # Make functionals
        m=Control(self.rho)
        self.J=0.5*inner(sig,eps)/self.J0*dx
        self.V=(rhoPhys-self.Volfrac)/self.VolMax*dx
        J=assemble(self.J)
        V=assemble(self.V)
        #self.Jhat = ReducedFunctional(J,m,tape=tape)
        #self.Vhat = ReducedFunctional(V,m,tape=tape)
        # Copy tape, to be able to run optimize such that e.g. mechanics is not solved for when calculating volume.
        tapeJ=tape.copy()
        tapeV=tape.copy()
        self.Jhat = ReducedFunctional(J,m,tape=tapeJ)
        self.Vhat = ReducedFunctional(V,m,tape=tapeV)
        tapeJ.optimize(controls=[m],functionals=[J])
        tapeV.optimize(controls=[m],functionals=[V])
        while annotate_tape():
            pause_annotation() # Run pause until we actually pause annotating...

    def f(self,x):
        """Redefine function from MMA that calculates the vector function f"""
        self.rho.vector().set_local(x.getArray()[:])
        self.rho.vector().apply('')

        J=self.Jhat(self.rho)
        V=self.Vhat(self.rho)
        return np.array([J,V])

    def g(self,x):
        """Redefine function from MMA that calculates the gradient (Jacobian) of f"""
        self.rho.vector().set_local(x.getArray()[:])
        self.rho.vector().apply('')
        dc=self.Jhat.derivative().vector().get_local()
        dv=self.Vhat.derivative().vector().get_local()
        return np.array([dc,dv])
    
    def optimize(self):
        # Set loglevel to 30 to disable some fenics messages...
        set_log_level(30)
        # For output of optimization history
        self.iter=0
        # Save markings for inspection in paraview
        File(self.directory+'boundary_parts.pvd') << self.mech.boundary_parts
        # Output files
        self.u_fid=File(self.directory+'u.pvd')
        self.rho_fid=File(self.directory+'rho.pvd')
        self.rhoFil_fid=File(self.directory+'rhoFil.pvd')
        self.rhoPhys_fid=File(self.directory+'rhoPhys.pvd')
        self.nout=5

        self.beta=1 
        self.eta=0.3
        betaMax=64 #Anton: Changed from 64 to 1 for computational time
        while self.beta<=betaMax:
            if self.rank==0:
                print('beta=',self.beta)
            self.setUpFunctionals(self.beta,self.eta)
            self.solve( self.rho_petsc )
            self.beta=self.beta*2
        self.beta=self.beta/2
        self.plot_k(True)
        (u,rho_bar,rho_tilde)=self.Forward(self.beta,self.eta)
        eps=self.mech.epsilon(u)
        sig=self.mech.sigma(u,eps)
        Energy=float(assemble(0.5*inner(sig,eps)*dx,annotate=False))
        Volume=float(assemble((Constant(1)+1e-9*rho_bar)*dx))
        UsedVolume=float(assemble(rho_bar*dx))
        return (Energy,UsedVolume,Volume)

if __name__ == "__main__":
    t=topOpt()
    if t.rank==0:
        print('DOFs in mechanics problem: ',t.mech.V.dim())
    (Energy,UsedVolume,Volume)=t.optimize()
    if t.rank==0:
        print('Final Average Strain Energy Density: ',Energy/Volume,'Final Volume fraction:',UsedVolume/Volume)
   
