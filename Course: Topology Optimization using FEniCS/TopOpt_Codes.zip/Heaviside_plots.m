clc; clearvars -except ; close all;
set(0,'DefaultFigureWindowStyle','normal') %Normal or docked
set(0,'DefaultFigureVisible','on')  %If you want to see the plot switch "off" with "on"
set(groot, 'defaultAxesTickLabelInterpreter','latex')
set(groot, 'defaultLegendInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');  
set(groot,'DefaultAxesTitle', 'latex')
set(0, 'DefaultAxesFontSize', 18);
get(0,'Factory');
set(0,'defaultfigurecolor',[1 1 1])

%%
eta = 0.5;
beta = [1, 8, 64];
rho = linspace(0,1,1000);
figure(1)
set(gcf,'Color',[227, 227, 227]/255); % Setting the background color
ax = gca; % Get current axes
set(ax, 'Color', [227, 227, 227]/255); % Setting the background color within the axes

for i=1:length(beta)
    rho_bar(i,:) = (tanh(beta(i)*eta) + tanh(beta(i)*(rho-eta)))/(tanh(beta(i)*eta)+tanh(beta(i)*(1-eta)));
    hold on
    plot(rho, rho_bar(i,:),'LineWidth',2)
end
title('Heaviside function for $\eta = 0.5$')
xlabel('$\tilde{\rho}$')
ylabel('$\bar{\rho}$')
legend('$\beta=1$','$\beta=8$', '$\beta=64$','Location','southeast')
box on
hold off

%%
eta = [0.3,0.5,0.7];
beta = 64;
rho = linspace(0,1,1000);
figure(2)
set(gcf,'Color',[227, 227, 227]/255); % Setting the background color
ax = gca; % Get current axes
set(ax, 'Color', [227, 227, 227]/255); % Setting the background color within the axes


for i=1:length(eta)
    rho_bar(i,:) = (tanh(beta*eta(i)) + tanh(beta*(rho-eta(i))))/(tanh(beta*eta(i))+tanh(beta*(1-eta(i))));
    hold on
    plot(rho, rho_bar(i,:),'LineWidth',2)
end
title('Heaviside function for $\beta = 64$')
xlabel('$\tilde{\rho}$')
ylabel('$\bar{\rho}$')
legend('$\eta=0.3$','$\eta=0.5$', '$\eta=0.7$','Location','southeast')
box on
hold off
