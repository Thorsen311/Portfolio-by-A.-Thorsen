from fenics import *
from fenics_adjoint import *
from cantilever_bracket import CantileverBracket
from filter_and_project import FilterAndProject
import numpy as np
from mma import MMA_petsc
from parallel import Parallel
import time

"""
To run from terminal:
conda activate fenics2019
cd Lektioner/EksamensOpgaveNy/DFilter_RobustMedParallel
mpiexec -n 3 python3 bracket_mma.py
"""
class topOpt(MMA_petsc):
    def __init__(self):
        # MPI rank
        self.rank=MPI.rank(MPI.comm_world)

        # Directory for output
        self.directory='topopt_elasticity_bracket/'

        # Some constants       
        density = 7850     # Density, [kg/m^3] 
        L1 = 40e-3              # Length, [m]
        L2 = 40e-3
        R1 = 30e-3
        R2 = 30e-3
        R3 = 12.5e-3
        g = 9.81
        F = -1000          # Total force, [N]
        Wz = 20e-3           #Thickness
        W = L2+R1+2*R2
        
        self.E0 = 111e9      # Youngs modulus, [Pa]
        self.nu = 0.3387     # Poissons ration, [1]
        mesh_size=W/80     # Mesh size
        
        self.Volfrac=0.5
        self.VolMax= (L1*L2) + (((L1+R1)*R1) - 1/4*np.pi*R1**2) + (( (L1+R1)*2*R2 ) + (1/2*np.pi*R2**2) - (np.pi*R3**2)) 
        
        R=W/8/(2*np.sqrt(3))  # Filter Radius
        self.R_DF = R/2       # Half filter radius for double filtering
        self.Emin=self.E0/1e6 # Minimum E
        self.pen=3            # SIMP penalization 
        
        self.mech=CantileverBracket(L1,L2,R1,R2,R3,Wz,self.E0,self.nu,F,density,mesh_size, comm=MPI.comm_world)
        #Write mesh for groups
        meshfile=self.directory+"/mesh.xdmf"
        with XDMFFile(self.mech.comm,meshfile) as f:
            f.write(self.mech.mesh)
        
        # Define group instances
        self.parallel=Parallel(MPI.comm_world,3)
        self.mech_group=CantileverBracket(L1,L2,R1,R2,R3,Wz,self.E0,self.nu,F,density,mesh_size, comm=self.parallel.group_comm,meshfile=meshfile)    
        
        # Create rho on global communicator
        self.Vd=FunctionSpace(self.mech.mesh,'DG',0)
        self.rho=interpolate(Constant(self.Volfrac),self.Vd)
        self.rho.rename('rho','rho')
        self.rho_petsc=as_backend_type(self.rho.vector()).vec()  # Pointer to rho's petsc data structure
        
        # Create rho on group communicator
        self.FP_group=FilterAndProject(R,self.mech_group.mesh) # Using group mesh also means using the group communicator
        self.rho_group=interpolate(Constant(self.Volfrac),self.FP_group.Vd)
        self.rho_group.rename('rho group','rho group')
        self.parallel.create_mapping(self.Vd,self.FP_group.Vd)
        
        # delta eta for robust optimization
        self.eta=0.5
        self.delta_eta=0.2
        if self.parallel.group==0:
            # Nominal design in group 0
            self.group_eta=self.eta
            self.eta_name='N'
        elif self.parallel.group==1:
            # Dialated design in group 1
            self.group_eta=self.eta-self.delta_eta
            self.eta_name='D'
        elif self.parallel.group==2:
            # Eroded design in group 2
            self.group_eta=self.eta+self.delta_eta
            self.eta_name='E'

        # Set up optimizer
        # Number of constraints
        self.ncon=4
        self.setUpOptimizer( self.rho_petsc )        
        print('__init__ done \n')
    
    def setUpOptimizer(self,x0):
        """Initializes MMA"""
        MMA_petsc.__init__(self,x0,self.ncon)
        self.xmin[:]=0.0
        self.xmax[:]=1.0
        self.setMinMax(3,1) #For MMA turn on min-max formulation by calling setMinMax with 3 'min-max' functions and 1 constraint
        
        # MMA setup
        self.move=0.5 #changed from 0.5
        self.xtol=0.01
        self.ftol=0.001
        self.lmax=5
        self.kmax=30 #This controls the max iterations - so changed from 30 for speed. 27/03/2024 with self.nout=5 30 doesn't work, but 31 does. 5 doesn't work but 6 does.
        self.kmin=30 #Forcing the optimizer to do all 30 iterations, makes it easier to determine in paraview what beta belongs to what
        self.it=0
        self.mma_timing=False  
        print('setUpOptimizer done \n')
    
    def Forward(self,beta):
        rho_tilde=self.FP_group.filter(self.rho_group)
        rho_bar,_=self.FP_group.Heavi_project(beta,self.eta-self.delta_eta,rho_tilde) #min(eta) = self.eta-self.delta_eta
        rho_Dtilde=self.FP_group.filter(rho_bar, R=self.R_DF) #self.R_DF=R/2
        betaDF = beta/2       
        rho_dbar,_=self.FP_group.Heavi_project(betaDF,self.group_eta,rho_Dtilde)
        
        E=self.Emin+pow(rho_dbar,self.pen)*(self.E0-self.Emin) # SIMP E
        self.mech_group.E=E
        self.mech_group.mask=rho_dbar
        u=self.mech_group.solve()
        
        return (u,rho_dbar,rho_tilde)
    

    def plot_k(self,x,force_plot=False):
        """Abstract method from mma, which can be used for output during optimization""" 
        if force_plot or self.iter % self.nout == 0:
            if not force_plot:
                self.rho.vector().set_local(self.x.getArray()[:])
                self.rho.vector().apply('')
            (u,rho_bar,rho_tilde)=self.Forward(self.beta)
            
            self.u_fid << u,self.iter
            self.rho_fid << self.rho,self.iter
            self.rhoFil_fid << rho_tilde,self.iter
            self.rhoPhys_fid << rho_bar,self.iter
            
            
            print('plot_k done \n')
        self.iter+=1
            
    def setUpFunctionals(self,beta):
        from pyadjoint.tape import annotate_tape
        while not annotate_tape():
            continue_annotation() # Run continue until we actually start annotating...
        tape=get_working_tape()
        tape.clear_tape()
        # Run forward model to record on tape
        (u,rhoPhys,rhoFil)=self.Forward(beta)
        eps=self.mech_group.epsilon(u)
        sig=self.mech_group.sigma(u,eps)
        # Using annotate=False to not record this step, such that J0 does not depend on rho
        if beta==1:
            self.J0=float(assemble(0.5*inner(sig,eps)*dx,annotate=False))
        # Make functionals
        m=Control(self.rho_group)
        self.J=0.5*inner(sig,eps)/self.J0*dx
        self.V=(rhoPhys-self.Volfrac)/self.VolMax*dx
        J=assemble(self.J)
        V=assemble(self.V)
        # Copy tape, to be able to run optimize such that e.g. mechanics is not solved for when calculating volume.
        tapeJ=tape.copy()
        tapeV=tape.copy()
        self.Jhat = ReducedFunctional(J,m,tape=tapeJ)
        self.Vhat = ReducedFunctional(V,m,tape=tapeV)
        tapeJ.optimize(controls=[m],functionals=[J])
        tapeV.optimize(controls=[m],functionals=[V])
        while annotate_tape():
            pause_annotation() # Run pause until we actually pause annotating... 
            
    def f(self,x):
        """Redefine function from MMA that calculates the vector function f"""
        self.rho.vector().set_local(x.getArray()[:])
        self.rho.vector().apply('')
        self.parallel.fglobal2group(self.rho,self.rho_group)
        
        J=self.Jhat(self.rho_group)
        V=self.Vhat(self.rho_group)
        self.Js=self.parallel.sgroup2global(J)
        self.Vs=self.parallel.sgroup2global(V)
        J_N,J_D,J_E=self.Js[:]
        V_N,V_D,V_E=self.Vs[:]
        self.move_max=-0.1    # Amount we want it to move
        return np.array([0,
                        (self.move_max-J_D)**2,
                        (self.move_max-J_E)**2,
                        (self.move_max-J_N)**2,
                        V_N])
    
    def g(self,x):
        """Redefine function from MMA that calculates the gradient (Jacobian) of f"""
        self.rho.vector().set_local(x.getArray()[:])
        self.rho.vector().apply('')
        self.parallel.fglobal2group(self.rho,self.rho_group)
        
        dc=self.parallel.vgroup2global(self.Jhat.derivative().vector())
        dv=self.parallel.vgroup2global(self.Vhat.derivative().vector())
        J_N,J_D,J_E=self.Js[:]
        V_N,V_D,V_E=self.Vs[:]
        dc_N,dc_D,dc_E=dc[0:3,:]
        dv_N,dv_D,dv_E=dv[0:3,:]
        return np.array([0*dc_N,
                        -2*(self.move_max-J_D)*dc_D,
                        -2*(self.move_max-J_E)*dc_E,
                        -2*(self.move_max-J_N)*dc_N,
                        dv_N]) 
    
    def optimize(self):
        # Set loglevel to 30 to disable some fenics messages...
        set_log_level(30)
        # For output of optimization history
        self.iter=0
        # Save markings for inspection in paraview
        File(self.directory+'boundary_parts.pvd') << self.mech.boundary_parts
        group_txt = str(self.eta_name)
        self.u_fid=File(self.directory+'u_'+group_txt+'.pvd')
        self.rho_fid=File(self.directory+'rho_'+group_txt+'.pvd')
        self.rhoFil_fid=File(self.directory+'rhoFil_'+group_txt+'.pvd')
        self.rhoPhys_fid=File(self.directory+'rhoPhys_'+group_txt+'.pvd')
        
        self.nout=5 
        self.beta=1
        betaMax=64 
        while self.beta<=betaMax:
            if self.rank==0:
                print('beta=',self.beta)
            self.setUpFunctionals(self.beta)
            print('Solving begins \n')
            self.solve( self.rho_petsc )
            print('Solving ends \n')
            self.beta=self.beta*2
        self.beta=self.beta/2
        self.plot_k(self.x, True)
        (u,rho_bar,rho_tilde)=self.Forward(self.beta)
        # Calculate stress
        eps=self.mech.epsilon(u)
        sig=self.mech.sigma(u,eps)        
        
        Energy=float(assemble(0.5*inner(sig,eps)*dx,annotate=False))
        Volume=float(assemble((Constant(1)+1e-9*rho_bar)*dx))
        UsedVolume=float(assemble(rho_bar*dx))
        return (Energy,UsedVolume,Volume)

if __name__ == "__main__":
    start_time = time.time()
    t=topOpt()
    if t.rank==0:
        print('DOFs in mechanics problem: ',t.mech.V.dim())
    (Energy,UsedVolume,Volume)=t.optimize()
    if t.rank==0:
        print('Final Average Strain Energy Density: ',Energy/Volume,'Final Volume fraction:',UsedVolume/Volume)
        end_time = time.time()
        # Calculate the total runtime
        runtime = end_time - start_time
        
        # Print the total runtime
        print("Total runtime: {:.2f} seconds".format(runtime))
