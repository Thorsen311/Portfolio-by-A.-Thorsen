from fenics import *
from fenics_adjoint import *
from mshr import *

class CantileverBracket:
    def __init__(self,L1,L2,R1,R2,R3,Wz,E,nu,F,density,mesh_size,comm=None,meshfile=None):
        # Use cell_type=CellType.Type.hexahedron for 3D
        # Inputs:
        #   L1, L2, R1, R2, R3, R3: Dimensions in x-y plane, [m]
        #   Wz: z width, [m]
        #   E: Youngs modulus, [Pa]
        #   nu: Poissons ration, [1]
        #   F: Force, [N]
        
        if comm is None:
            self.comm=MPI.comm_world
        else:
            self.comm=comm
            
        self.traction = F/(pi*R3*Wz)  # Traction, [N/m^2]
        g=9.81                      # Gravitational acceleration, [m/s^2]

        self.E = E
        self.nu = nu
        self.mask=1               # Can be used to mask out part of the geometry in the body force
        self.mesh_size=mesh_size
        self.dim = 2              # 2 dimensions
            
        # Create mesh and define function space
        if meshfile is None:
            rec1 = Rectangle(Point(0, 0), Point(L2,L1))

            rec2 = Rectangle(Point(L2, -R2), Point(L2+R1,L1))
            circ1 = Circle(Point(L2, -R2), R1)

            rec3 = Rectangle(Point(L2+R1, -R2), Point(L2+R1+R2*2,L1))
            circ2 = Circle(Point(L2+R1+R2, -R2), R2)
            circ3 = Circle(Point(L2+R1+R2, -R2), R3)
            # Subtract the holes from the bracket
            domain = rec1+(rec2-circ1)+((rec3+circ2)-circ3)
            dolf_mesh = generate_mesh(domain, 64)
            self.mesh = Mesh(dolf_mesh)
        else:
            self.mesh = Mesh(self.comm)
            with XDMFFile(self.comm,meshfile) as f:
                f.read(self.mesh)
                
        self.V = VectorFunctionSpace(self.mesh, 'P', 1)
        self.f = Constant((0, -density*g))         # Body force
        self.T = Constant((0, self.traction))
        
        # Define boundary condition
        tol = self.mesh_size/2

        class clamped_boundary(SubDomain):
            def inside(self, x, on_boundary):
                return on_boundary and near(x[0], 0, tol)

        class load_boundary(SubDomain):
            def inside(self, x, on_boundary):
                # Define the center and radius of the circle
                center_x = L2+R1+R2
                center_y = -R2
                radius = R3
        
                # Calculate the distance from the center of the circle to the point
                dist = sqrt((x[0] - center_x)**2 + (x[1] - center_y)**2)
        
                # Check if the point is on the boundary, within the circle, and in the bottom half
                return on_boundary and dist <= radius+tol and x[1] <= center_y

        if self.dim==2:
            self.boundary_parts = MeshFunction("size_t", self.mesh, 1)
        else:
            self.boundary_parts = MeshFunction("size_t", self.mesh, 2)
        self.boundary_parts.set_all(0)
        load_boundary().mark(self.boundary_parts,1)    # Load on boundary 1
        clamped_boundary().mark(self.boundary_parts,2) # Fixed on boundary 2

        # Define new surface measure with marked surfaces
        self.ds = Measure('ds', domain=self.mesh, subdomain_data=self.boundary_parts)
        if self.dim==2:
            self.bc = DirichletBC(self.V, Constant((0, 0)), self.boundary_parts, 2)
        else:
            self.bc = DirichletBC(self.V, Constant((0, 0, 0)), self.boundary_parts, 2)

        # Solver
        self.KrylovSolver="cg"
        self.KrylovPrecon="hypre_amg"

    # Define strain and stress
    def epsilon(self,u):
        return 0.5*(grad(u)+grad(u).T)

    def sigma(self,u,eps=None,E=None):
        if eps is None:
            eps=self.epsilon(u)
        if E is None:
            E=self.E
        d = u.geometric_dimension()
        mu = E/(2*(1+self.nu))
        lambda_ = E*self.nu/((1+self.nu)*(1-2*self.nu))
        return lambda_*tr(eps)*Identity(d)+2*mu*eps

    def solve(self):
        # Define variational problem
        u = TrialFunction(self.V)
        v = TestFunction(self.V)
        a = inner(self.sigma(u), self.epsilon(v))*dx
        L = self.mask*dot(self.f, v)*dx + dot(self.T, v)*self.ds(1) # body force with mask, traction only on boundary 1

        # Compute solution
        u = Function(self.V,name='Displacement') # 'name' shown in paraview
        solve(a == L, u, self.bc, solver_parameters={"linear_solver": self.KrylovSolver, "preconditioner": self.KrylovPrecon})
        return u

    def vonMises(self,u):
        d = u.geometric_dimension()  # space dimension
        stress=self.sigma(u)
        s = stress - (1./3)*tr(stress)*Identity(d)  # deviatoric stress
        von_Mises = sqrt(3./2*inner(s, s))
        Vc = FunctionSpace(self.mesh, 'P', 1)
        von_Mises = project(von_Mises, Vc)
        von_Mises.rename('von Mises','von Mises stress')
        return von_Mises

    def gradient(self,u,rho,drho):
        eps=self.epsilon(u)

        d = u.geometric_dimension()
        dE=derivative(self.E,rho,drho)
        mu = dE/(2*(1+self.nu))
        lambda_ = dE*self.nu/((1+self.nu)*(1-2*self.nu))
        dSigma=lambda_*tr(eps)*Identity(d)+2*mu*eps
        
        g=assemble(-1/2*inner(dSigma,eps)*dx)
        return g

if __name__ == "__main__":
    set_log_level(30)
    
    density = 7850     # Density, [kg/m^3] 
    L1 = 40e-3              # Length, [m]
    L2 = 40e-3
    R1 = 30e-3
    R2 = 30e-3
    R3 = 12.5e-3
    g = 9.81
    F = -1000          # Total force, [N]
    Wz = 20e-3           #Thickness
    W = L2+R1+2*R2
    
    E=111e9      # Youngs modulus, [Pa]
    nu = 0.3387     # Poissons ration, [1]
    mesh_size=W/50     # Mesh size  
    
    bracket=CantileverBracket(L1,L2,R1,R2,R3,Wz,E,nu,F,density,mesh_size)
    u=bracket.solve()

    # Calculate stress
    von_Mises=bracket.vonMises(u)

    # Calculate magnitude of displacement
    V = FunctionSpace(bracket.mesh, 'P', 1)
    u_magnitude = sqrt(dot(u, u))
    u_magnitude = project(u_magnitude, V)
    u_magnitude.rename('magnitude','magnitude')
    print('min/max u:',
          u_magnitude.vector().min(),
          u_magnitude.vector().max())

    # Save solution to file in VTK format
    File('cantilever_bracket/displacement.pvd') << u
    File('cantilever_bracket/von_mises.pvd') << von_Mises
    File('cantilever_bracket/magnitude.pvd') << u_magnitude